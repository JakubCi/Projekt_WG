function showImages(el) {
    var windowHeight = jQuery( window ).height();
    $(el).each(function(){
        var thisPos = $(this).offset().top;
        var topOfWindow = $(window).scrollTop();
        if (topOfWindow + windowHeight - 100 > thisPos ) {
            $(this).addClass("fadeIn");
        }
    });
}
$(document).ready(function(){
        showImages('#zdjecie1');
        showImages('#zdjecie5');
        showImages('.omn1');
        showImages('.kon1')
        showImages('.opi1')
        showImages('.omn2')
});
$(window).scroll(function() {
        showImages('#zdjecie1');
        showImages('#zdjecie5');
        showImages('.omn1');
        showImages('.kon1')
        showImages('.opi1')
        showImages('.omn2')
});