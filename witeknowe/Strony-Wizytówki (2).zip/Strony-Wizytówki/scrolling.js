$(function () {
    var $win = $(window);

    $win.scroll(function () {
        if ($win.scrollTop() <50){                     
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.1)');
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.1)');
        }
        else if (($win.scrollTop()>50)&&($win.scrollTop()<100)) {
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.2)');  
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.2)');          
        }
        else if (($win.scrollTop()>=100)&&($win.scrollTop()<150)) {            
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.3)');  
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.3)');            
        }
        else if (($win.scrollTop()>=150)&&($win.scrollTop()<200)) {            
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.4)');   
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.4)');          
        }
        else if (($win.scrollTop()>=200)&&($win.scrollTop()<250)) {        
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.5)'); 
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.5)');               
        }
        else if (($win.scrollTop()>=250)&&($win.scrollTop()<300)) {                     
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.6)');   
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.6)');              
        }
        else if (($win.scrollTop()>=300)&&($win.scrollTop()<350)) {                     
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.7)');  
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.7)');                  
        }
        else if (($win.scrollTop()>=350)&&($win.scrollTop()<400)) {                      
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.8)');  
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.8)');                  
        }
        else if (($win.scrollTop()>=400)&&($win.scrollTop()<450)) {                    
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 0.9)'); 
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 0.8)');                     
        }
        else if ($win.scrollTop()>=450) {         
            $('.top-nav').css('background-color', 'rgba(156, 156, 156, 1)');
            $('#kolkoXD').css('background-color', 'rgba(156, 156, 156, 1)');
        }
        if($win.scrollTop()>400){
            $('#company-name').css('color', 'rgba(22,22,22, 1)');
            $('#top-nav-items li a:hover').css('color', 'rgb(122, 122, 122)');
            $('#top-nav-items li a').css('color', 'rgba(22,22,22, 1)');
            
        }
        else if($win.scrollTop()<=400){
            $('#company-name').css('color', 'rgba(66, 66, 66,0.95)');
            $('#top-nav-items li a:hover').css('color', 'rgb(255, 255, 255)');
            $('#top-nav-items li a').css('color', 'rgba(66, 66, 66,0.95)');
            
        }
    });
});