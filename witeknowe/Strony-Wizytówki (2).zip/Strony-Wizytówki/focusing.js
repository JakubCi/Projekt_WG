let omnie=document.querySelector("a[id='omnie']")
omnie.addEventListener('click',funkcja1)
let onas=document.querySelector("a[id='onas']")
onas.addEventListener('click',funkcja4)

let opinie=document.querySelector("a[id='opinie']")
opinie.addEventListener('click',funkcja3)
let omniediv=document.querySelector("div[name='omn']")
let kontaktdiv=document.querySelector("div[name='kon']")
let opiniediv=document.querySelector("div[name='opi']")
let przycisk=document.querySelector("div[class='container']")
function funkcja1(){
    omniediv.focus({preventScroll:false})    
}

function funkcja3(){
    opiniediv.focus({preventScroll:false})
}
function funkcja4(){
    przycisk.click()
    omniediv.focus({preventScroll:false})
}
